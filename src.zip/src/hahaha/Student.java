package hahaha;

public class Student {// ѧ����
	private int num;
	private String name;
	private int age;
	private int java;
	private int C;
	private int html;
	private int sql;

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getJava() {
		return java;
	}

	public void setJava(int java) {
		this.java = java;
	}

	public int getC() {
		return C;
	}

	public void setC(int c) {
		C = c;
	}

	public int getHtml() {
		return html;
	}

	public void setHtml(int html) {
		this.html = html;
	}

	public int getSql() {
		return sql;
	}

	public void setSql(int sql) {
		this.sql = sql;
	}

	public String toString() {
		String str = "\t" + this.num + "\t" + this.name + "\t" + this.age + "\t" + this.java + "\t" + this.C + "\t"
				+ this.html + "\t" + this.sql;
		return str;
	}
}
